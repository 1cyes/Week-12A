# Isaias Gonzalez

# prep
repo: https://github.com/1cyes/Week-12A
gitTest: What I did was decide to use the correct repository to use for this assignment. I connected the repository with the website so every saved from the website will be connected straight to the repository I connected. The evidence is https://github.com/1cyes/Week-12A.git, this is evidence by opening up that GitHub link you would see every change I did here be there recorded into the repository.
access: What I tested was when backing up from the website, would it backup in the GitHub repository. When my team and I did this task we learned that it was a success.
video1: First I saw and listened to the video. Then observed that into game development you need to having a growth mindset, great folder structure ( be organized), and have documentation ( for better understanding of the thing that are needed to do and knowing how to do such thing). 
video2: What I did was to listen the video. Then I observed what needed to be done to have a developer mindset and which was to essentially success in the complex and challenging world of game development , by practical strategies  to overcome common obstacles, as technical issues, while maintaining motivation through organization and continuous learning.
video3: What I did was to observed the video about folder structure and what it the best way into doing it. And by the video leaners needs to highlight the important folder structure to improve team efficiency and project management. Then the leader demonstrates how to use a extensions like the Talstra Folder Maker application (showed in the video) that uses custom JSON templates to automate the creation of a essential documentation and project logs.
video4: What I did was to observed the video about documentation and organizing project and what is the best way to do it. Which is by  using a pre-established folder structure. Then the leader demonstrates how to customize a Game Development Document template and explains the function of key project folders like resources, assets, and study area. Also to outline structures to a four-step pipeline to help teams manage their game development process from initial setup through to publishing.
video5: What I did was to observed the video about Intro to Unity. It helps beginners to set up Unity projects and emphasizing proper file management to avoid directory errors. Shows the essentials of the Unity interface and demonstrates basic navigation and character movement controls. The goal is to establish a functional 3D game foundation using a pre-built template, which will be further customized in the future.
video6: What I did was to observed the video about how to import a custom player of your own. And how to do it was by configuring the proper humanoid rig and applying embedded materials. Then the video further explains how to replace a default player mesh by unpacking its prefab and assigning a new avatar to the armature for gameplay integration.
opinion: This pipeline can help future projects/stories. As it helped us understand more about proper organization of folders and files, then help us organize the documentation needed as to tell what we did and need to do in the future, also to have a growth mindset and having it grow so you can think more outside and inside the box for more interesting ideas. With this pipeline it can also help the team acknowledge who is a teammate and tool and if they bring anything to the table or if they are worthy to be in the team.
questions: Out of everything in this pipeline which is more important and why.

# prepBoard
notes: The diagram shows the five main things I learned about game development, from having a growth mindset to importing a custom player in Unity. It explains how to stay organized, document work, and build the foundation for creating a 3D game.

## pen
color: #153f48
size: 2